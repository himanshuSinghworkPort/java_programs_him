package Lalit.kumar;

import java.awt.Desktop;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;  
import java.io.IOException;  
import java.util.HashMap;  
import java.util.Map;
import java.text.SimpleDateFormat;
import java.util.Date; // Import Date and SimpleDateFormat classes
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JOptionPane; // Importing JOptionPane


import com.google.zxing.BarcodeFormat;  
import com.google.zxing.EncodeHintType;  
import com.google.zxing.MultiFormatWriter;  
import com.google.zxing.NotFoundException;  
import com.google.zxing.WriterException;  
import com.google.zxing.client.j2se.MatrixToImageWriter;  
import com.google.zxing.common.BitMatrix;  
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;  





public class App extends JFrame implements ActionListener
{  
	
	JLabel label;
	JTextArea text;
	JButton button;
	static String url;
	JLabel QRLabel;
	JLabel image;
	ImageIcon Icon ;
	JButton buttonDownload;
	JButton buttonView;
	
	public App() {
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLayout(null);
		this.setBounds(500,100,700,700);
		
		
		label = new JLabel();
		label.setText("Enter Your Link : ");
		label.setFont(new Font("Arial", Font.PLAIN,20));
		//label.setBounds(220, 140, 200, 30);
		label.setBounds(100, 100, 250, 100);
		
		
		text = new JTextArea();
		text.setFont(new Font("Verdana", Font.BOLD,14));
		text.setBounds(260, 140, 250, 30);
		
		//Get QR Button
		button = new JButton("Get QR");
		button.setBounds(250, 200, 100, 30);
		button.addActionListener(this);
		
		
		
		
		
		this.add(button);
		this.add(text);
		this.add(label);
		
		
		this.setVisible(true);	
		}
	
	
	//static function that creates QR Code  
	public static void generateQRcode(String data, String path, String charset, Map map, int h, int w) throws WriterException, IOException  
	{  
		//the BitMatrix class represents the 2D matrix of bits  
		//MultiFormatWriter is a factory class that finds the appropriate Writer subclass for the BarcodeFormat requested and encodes the barcode with the supplied contents.  
		BitMatrix matrix = new MultiFormatWriter().encode(new String(data.getBytes(charset), charset), BarcodeFormat.QR_CODE, w, h);  
		MatrixToImageWriter.writeToFile(matrix, path.substring(path.lastIndexOf('.') + 1), new File(path));  
	}  
	
	
	//main() method  
	public static void main(String args[]) throws WriterException, IOException, NotFoundException  
	{  
	
		new App();

	}


	//Action Performed
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==button) {
			url = text.getText();
			
			try {
				createQR();
			} catch (WriterException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			
			//Display QR
			Icon = new ImageIcon("qr.png");
			image = new JLabel(Icon);
			image.setBounds(200, 300, Icon.getIconWidth(), Icon.getIconHeight());
			this.add(image);
			
			//Download Button
			buttonDownload = new JButton("Download & Share");
			buttonDownload.setBounds(190, 550, 100, 30);
			buttonDownload.addActionListener(this);
			this.add(buttonDownload);
			
			//View Button
			buttonView = new JButton("View");
			buttonView.setBounds(310, 550, 100, 30);
			buttonView.addActionListener(this);
			this.add(buttonView);
			
			
			this.setBounds(500,100,700,701);
		}

		
		if (e.getSource() == buttonDownload) {
            try {
                downloadQR();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }
		
		
		if (e.getSource() == buttonView) {
            try {
                viewQR();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }
	}
	
	


	private void createQR() throws WriterException, IOException {
		
		//data that we want to store in the QR code  
		String str= url;  
		//path where we want to get QR Code  
		String path = "qr.png";  
		//Encoding charset to be used  
		String charset = "UTF-8";  
		Map<EncodeHintType, ErrorCorrectionLevel> hashMap = new HashMap<EncodeHintType, ErrorCorrectionLevel>();  
		//generates QR code with Low level(L) error correction capability  
		hashMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);  
		//invoking the user-defined method that creates the QR code  
		generateQRcode(str, path, charset, hashMap, 200, 200);//increase or decrease height and width accodingly   
		//prints if the QR code is generated   
		System.out.println("QR Code created successfully.");  
		}
	
	
	// Method to download the QR code image
    private void downloadQR() throws IOException {
        String sourceFilePath = "qr.png"; // Source path of the QR code image
//        String destinationFilePath = "C:\\Users\\a3lal\\Downloads\\download_QR_"+url+".png"; //Destination path for downloading
        

     // Create a unique filename for each download using the current timestamp
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        String timestamp = sdf.format(new Date());
        String destinationFilePath = "C:\\Users\\a3lal\\Downloads\\download_QR_" + timestamp + ".png"; // Destination path for downloading

        File sourceFile = new File(sourceFilePath);
        File destinationFile = new File(destinationFilePath);

        // Copy the file from source to destination
        Files.copy(sourceFile.toPath(), destinationFile.toPath(), StandardCopyOption.REPLACE_EXISTING);

        System.out.println("QR Code downloaded successfully."); 
    }

    
    // Method to share the downloaded QR code image
    private void viewQR() throws IOException {
        String destinationFilePath = "C:\\Users\\a3lal\\Downloads";
        File destinationFile = new File(destinationFilePath);
        
        if (destinationFile.exists()) {
            try {
                // Use the Desktop API to open the file in the default image viewer
                Desktop.getDesktop().open(destinationFile);
            } catch (IOException e) {
                e.printStackTrace();
                // Show an error message if there is an issue with opening the file
                JOptionPane.showMessageDialog(this, "Error opening the QR code image.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            // Show an error message if the file does not exist
            JOptionPane.showMessageDialog(this, "The QR code image does not exist.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

}	

