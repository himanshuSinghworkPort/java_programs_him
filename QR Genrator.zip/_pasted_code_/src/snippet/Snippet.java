package snippet;

public class Snippet {
	public static void main(String[] args) {
		Icon = new ImageIcon("qr.png");
					image = new JLabel(Icon);
					image.setBounds(200, 300, Icon.getIconWidth(), Icon.getIconHeight());
					this.add(image);
	}
}

